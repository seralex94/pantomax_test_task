<!DOCTYPE html>
<html lang="en">
<html prefix="og: http://ogp.me/ns#">
<head>
    <meta property="og:title" content="Продадим вашу квартиру быстро и дорого c комиссией от 0%">
    <meta property="og:site_name" content="Bogoslavsky">
    <meta property="og:url" content="http://bogoslavsky.com">
    <meta property="og:description" content="Как получить лучшую цену при самых коротких сроках. Эффективная методика продажи">
    <meta property="og:image" content="https://bogoslavsky.com/img/discript2.jpg">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta property="fb:app_id" content="368081597034436" />
    <title>Bogoslavsky - продажа недвижимости быстро и дорого</title>
    <meta name="title" content="Bogoslavsky Team – команда профессиональных риелторов" />
	<meta name="description" content="Продажа квартиры по самой лучшей цене в Киеве ☎: +38 (093) 240-07-45" />
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800,800i" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/media.css">
    <!--<link rel="stylesheet" href="css/animate.css">-->

    <!--таймер-->
    <link href="css/timeTo.css" type="text/css" rel="stylesheet"/>
    <!--таймер-->
    <!--всплывающие окна-->
    <link rel="stylesheet" href="js/modal-window/jquery.arcticmodal-0.3.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="js/modal-window/jquery.arcticmodal-0.3.min.js"></script>
    <!--<script src="jquery.min.js"></script>-->
    <!--<script src="owlcarousel/owl.carousel.min.js"></script>-->
    <!--слайдер-->
    <!--mask tel-->
    <script src="js/maskinput.js"></script>
    <script src="js/timer.min.js"></script>
    <!--mask tel-->
    <!--всплывающие окна-->
    <!--слайдер-->
    <!-- <link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css"> -->
    <link rel="stylesheet" href="css/timer.min.css">

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-120607619-1"></script>
<script>
	window.dataLayer = window.dataLayer || [];
	function gtag(){
		dataLayer.push(arguments);
	}
	gtag('js', new Date());
	gtag('config', 'UA-120607619-1', {'send_page_view': false});
    gtag('config', 'AW-800883001');
</script>
<script>
	function initRingostat(){
		if (typeof(ga) !== 'undefined') {
			ga('gtag_UA_120607619_1.require','ringostat');
			gtag('event', 'page_view');
			(function (d,s,u,e,p) {
				p=d.getElementsByTagName(s)[0],e=d.createElement(s),e.async=1,e.src=u,p.parentNode.insertBefore(e, p);
			})(document, 'script', 'https://script.ringostat.com/v4/78/78877ebe7297b675f1c95468143b5d1790f0192c.js');
		} else {
			setTimeout(initRingostat,200);
		}
	}
	initRingostat();
</script>
<!-- Event snippet for Клики по номеру на моб сайте conversion page
In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
<script>
function gtag_report_conversion(url) {
  var callback = function () {
    if (typeof(url) != 'undefined') {
      window.location = url;
    }
  };
  gtag('event', 'conversion', {
      'send_to': 'AW-800883001/CsvwCK6YlqMBELmC8v0C',
      'event_callback': callback
  });
  return false;
}
</script>

<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://cdn.jsdelivr.net/npm/yandex-metrica-watch/tag.js", "ym");

   ym(53323897, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/53323897" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

<!-- Marquiz script start -->
<script src="//script.marquiz.ru/v1.js" type="application/javascript"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
  Marquiz.init({ 
    id: '5d869b048243430044992f9b', 
    autoOpen: false, 
    autoOpenFreq: 'always', 
    openOnExit: true 
  });
});
</script>
<!-- Marquiz script end -->

</head>
<body>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/ru_RU/sdk.js#xfbml=1&autoLogAppEvents=1&version=v3.0&appId=368081597034436';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!-- Липкое меню -->
<div class="header-menu">
    <div class="container">
        <div class="row menu-logo-padding">
        	
            <div class="col-md-3 header-logo-padding" ID = "toTop" >
                <a href="#"><img src="img/logo-feel.png" alt="" class="header-menu-logo" id="top_scroll"></a>
            </div>
            <div class="col-lg-9 col-md-12">
                <ul class="header-menu-ul">
                    <li class="header-menu-li"><span class="header-menu-timetable-day">Пн-Пт</span> <span class="header-menu-timetable-num">9<sup>00</sup>-19<sup>00</sup></span></li>
                    <li class="header-menu-li" id="header-menu-li-padding"><span class="header-menu-timetable-day">Сб</span> <span class="header-menu-timetable-num">10<sup>00</sup>-17<sup>00</sup></span></li>
                    <li class="header-menu-li"><span class="header-menu-phone"><a onclick="" href="tel:+380932400745"> <span class="header-menu-phone-bold"><span>(093)</span> 240-07-45</span></a></span></li>
                </ul>

                <ul class="header-menu-ul-button">
                    <li class="header-menu-li-button"><a href="#learn-more" class="header-menu-li-button-a topLink">Преимущества</a></li>
                    <li class="header-menu-li-button"><a href="#sevensteps" class="header-menu-li-button-a topLink">Схема работы</a></li>
                    <li class="header-menu-li-button"><a href="#reviews" class="header-menu-li-button-a topLink">Отзывы</a></li>
                    <li class="header-menu-li-button"><a href="#kontakt" class="header-menu-li-button-a topLink">Контакты</a></li>
                    <li class="header-menu-li-button"><a href="https://bogoslavsky.com/blog" class="header-menu-li-button-a  topLink">Блог</a></li>
                    <span class="header-phone"><a onclick="" href="tel:+380932400745"> <span class="header-menu-phone-bold"><span>(093)</span> 240-07-45</span></a></span>
                </ul>
            </div>
        </div>
    </div>
</div>

<!--Экран верхний -->
<header class="header">
    <div class="container">
        <div class="row logo-padding">
            <div class="col-md-12 col-lg-8 col-sm-12 col-12">
                <img src="img/logo-feel.png" alt="" class="header-logo" id="top_scroll">
            </div>
            <div class="toggle-mnu"></div>
            <div class="col-md-6 col-lg-4 col-sm-6 mob-none col-6">
                <span class="header-phone"><a href="tel:+380932400745"> <span class="header-menu-phone-bold"><span>(093)</span> 240-07-45</span></a></span>
                
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <h1 class="header-h1">Срочно продадим Вашу квартиру с комиссией от 0%<br>
                    <span class="header-h1-mini"></span>
                </h1>
                <h3 class="header-h4">Киев</h3>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <ul class="header-ul">
                   <div class="marquiz__container">
  <a class="marquiz__button marquiz__button_blicked marquiz__button_shadow" href="tel:+380932400745" data-fixed-side="" data-alpha-color="rgba(238, 174, 15, 0.5)" data-color="#eeae0f" data-text-color="#111">ПОЗВОНИТЬ СЕЙЧАС</a>
</div>
                </ul>
            </div>
        </div>


    </div>
</header>

<!--скос -->
<section class="timer-bg-rot"></section>

<!--Экран с таймером -->
<section class="timer" style="display: none">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <img src="img/bedroom-360.png" alt="" class="timer-img" style="width: 284px;">
            </div>
            <div class="col-lg-8">
                <h3 class="timer-title">Только на этой неделе!</h3>
                <p class="timer-text">
                    При заключении договора на оказание услуг по <br> продаже квартиры - <span class="timer-text-bold">виртуальный тур в<br> подарок!</span>
                </p>

                <div class="timer-block">
                    <div class="timer-block-left">
                        <script src="js/7179f6234fa8ecbc59baf69073d1047f.js"></script>
                    </div>
                    <div class="timer-block-right">
                        <img src="img/arrow%20green.png" alt="" class="timer-block-arrow">
                    </div>
                </div>

                <div class="timer-form">
                    <div class="form-mini" id="timer-form-mini">
                        <form action="mail.php" method="post" name="form">
                            <input type="hidden" name="utm_content" value="<?=$_GET['utm_content']?>">
                            <input type="hidden" name="utm_medium" value="<?=$_GET['utm_medium']?>">
                            <input type="hidden" name="utm_source" value="<?=$_GET['utm_source']?>">
                            <input type="hidden" name="utm_campaign" value="<?=$_GET['utm_campaign']?>">
                             <input type="hidden" name="utm_term" value="<?=$_GET['utm_term']?>">
                            <ul class="timer-ul">
                                <li class="timer-li"><input type="tel" placeholder="Ваш телефон" required=""  name="phone" value="" id="tel1"></li>
                                <li class="timer-li" id="timer-li-margin"><input type="submit" value="ОТПРАВИТЬ ЗАЯВКУ" name="submit" class="form-button-style"></li>
                            </ul>
                            <input type="hidden"  required="" name="hidden" value="Письмо отпрвлено с всплывающей формы">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<!--Экран 5 очевидных преимуществ -->
<section class="advantages" id="learn-more">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="advantages-title">Ваши 4 очевидных <span class="advantages-green">преимущества</span> работая с нами</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <ul class="advantages-ul">
                    <li class="advantages-li">
                        <div class="circle">
                            <img src="img/p1.png" alt="" class="advantages-circle-img-1">
                        </div>
                        <span class="circle-title">Комиссия</span>
                        <span class="circle-text">Вы сами выбирайте по какой системе комиссии работать<br>0 или 5%</span>
                    </li>

                    <li class="advantages-li">
                        <div class="circle" >
                            <img src="img/p5.png" alt="" class="advantages-circle-img-2">
                        </div>
                        <span class="circle-title">Аналитика</span>
                        <span class="circle-text">мы бесплатно проанализируем рынок недвижимости и объективно сориентируем по цене и срокам продажи</span>
                    </li>

                    <li class="advantages-li">
                        <div class="circle">
                            <img src="img/p4.png" alt="" class="advantages-circle-img-4">
                        </div>
                        <span class="circle-title">Маркетинг</span>
                        <span class="circle-text">мы сотрудничаем с маркетинговым агентством, которое сильно повысит эффективность продажи Вашей недвижимости</span>
                    </li>
	
                    <li class="advantages-li">
                        <div class="circle">
                            <img src="img/p3.png" alt="" class="advantages-circle-img-5">
                        </div>
                        <span class="circle-title">Оплата</span>
                        <span class="circle-text">Вы оплачиваете по факту продажи или комиссию оплачивает покупатель</span>
                    </li>
                </ul>
            </div>
        </div>

        <!--<div class="row">
            <div class="col-lg-12">
                <div class="advantages-bloknot">
                    <img src="img/i_bloknot.png" alt="" class="advantages-bloknot-img">
                </div>
            </div>
        </div>-->
    </div>
</section>

<!-- Экран продать квартиру -->
<section class="apartment-for-sale" id="apartment-sale" style="display: none">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="apartment-for-sale-title">ПРОДАЖА КВАРТИРЫ</h2>
                <h5 class="apartment-for-sale-city rotatable">В КИЕВЕ</h5>
				<center><p><b>И так, Вы решили продать свою квартиру. <br>С чего начать и как получить лучшую цену на рынке?</b></p></center>
                <p align="justify"><b>С поиска риелтора в Киеве.</b> За последние годы на рынке недвижимости Киева произошло серьезное снижение покупательского спроса. Продать свою квартиру по лучшей цене без помощи профессионала – сложная задача для собственника. </p>

                <p align="justify"><b>Далее, определить правильную стартовую цену на квартиру.</b> Профессионалы знают реальные цены сделок, нам доступны закрытые базы проданных объектов. Наш опыт показывает, что собственники в процессе самостоятельной продажи теряют, как минимум 10% от возможной максимальной цены.</p>

                <p>&nbsp;</p>

                <h3 class="apartment-for-sale-green">Эффективная методика продажи!</h3>

                <div class="apartment-for-sale-house">
                    <img src="img/vershina_yspeha1.png" alt="" class="apartment-for-sale-house-img">
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-lg-3">

            </div>
            <div class="col-lg-9">
                <ul class="apartment-for-sale-ul">
                    <li class="apartment-for-sale-li">
                        <div class="apartment-for-sale-li-left">
                            <img src="img/s1_new.png" alt="" class="apartment-for-sale-li-left-img">
                        </div>
                        <div class="apartment-for-sale-li-right">
                            <span class="apartment-for-sale-li-right-title">Оценка стоимости</span><br>
                            <span class="apartment-for-sale-li-right-text">Профессиональная оценка с учетом факторов спроса и реальных продаж</span>
                        </div>
                    </li>

                    <li class="apartment-for-sale-li">
                        <div class="apartment-for-sale-li-left">
                            <img src="img/s2_new.png" alt="" class="apartment-for-sale-li-left-img">
                        </div>
                        <div class="apartment-for-sale-li-right">
                            <span class="apartment-for-sale-li-right-title">Подготовка к продаже</span><br>
                            <span class="apartment-for-sale-li-right-text">Подписание соглашения, профессиональная фотосессия, рекламная кампания</span>
                        </div>
                    </li>

                    <li class="apartment-for-sale-li">
                        <div class="apartment-for-sale-li-left">
                            <img src="img/s3_new.png" alt="" class="apartment-for-sale-li-left-img">
                        </div>
                        <div class="apartment-for-sale-li-right">
                            <span class="apartment-for-sale-li-right-title">Поиск покупателя</span><br>
                            <span class="apartment-for-sale-li-right-text">Переговоры с покупателями, регулярные отчеты, получение лучшей цены</span>
                        </div>
                    </li>

                    <li class="apartment-for-sale-li">
                        <div class="apartment-for-sale-li-left">
                            <img src="img/s4_new.png" alt="" class="apartment-for-sale-li-left-img" >
                        </div>
                        <div class="apartment-for-sale-li-right">
                            <span class="apartment-for-sale-li-right-title">Проведение сделки</span><br>
                            <span class="apartment-for-sale-li-right-text">Подписание договора купли-продажи, расчет с продавцом, оплата услуги</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <p align="justify"><b>Тщательно подготовить квартиру к продаже.</b> Это значит - усилить привлекательность объекта, навести блеск в квартире и в парадном, создать ощущение комфорта и благополучия жилья у покупателя, «влюбить» его в Ваш товар.</p>

                <p align="justify"><b>Разработать и запустить целевую рекламную кампанию.</b> У нас значительно больше специфических инструментов и партнерских каналов продаж. Мы изучаем спрос, формируем портрет покупателя, настраиваем рекламную кампанию Вашего объекта точно в цель! </p>

                <p align="justify"><b>Провести переговоры с покупателями.</b> Так, чтобы получить лучшую цену за объект. При этом, с нами Вы можете избежать изматывающих торгов с эмоциональными покупателям, и их агентами, которые с помощью психологических манипуляций добиваются торга «вниз»!</p>
                <p>&nbsp;</p>
            </div>
        </div>
    </div>
</section>








<!--Экран рассчет реальной стоимости вашей квартиры-->
<!-- <section class="costing">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="costing-title">
                    <span class="costing-title-thin">РАСЧЕТ</span><br>
                    <span class="costing-title-bold">РЫНОЧНОЙ СТОИМОСТИ</span><br>
                    <span class="costing-title-thin-2">ВАШЕЙ КВАРТИРЫ</span>
                </h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="form" id="costing-form">
                    <span class="footer-form-title">Оставьте заявку</span><br>
                    <span class="footer-form-text">и получите профессиональный расчет рыночной стоимости Вашей квартиры:</span>
                    <form action="mail.php" method="post" name="form">
                        <input type="text" placeholder="Ваше имя" required=""  name="name" value=""><br>
                        <input type="tel" placeholder="Ваш телефон" required=""  name="phone" value="" id="tel3"><br>
                        <input type="hidden"  required="" name="hidden" value="Письмо отпрвлено с всплывающей формы">
                        <input type="submit" value="РАССЧИТАТЬ" name="submit" class="form-button-style">
                    </form>
                </div>
            </div>
            <div class="col-lg-8">
                <img src="img/arrow%20green.png" alt="" class="arrow-green">
            </div>
        </div>
    </div>
</section> -->
<section class="technologies">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="technologies-title">
                    <span class="technologies-title-bold">Хотите срочно продать свою недвижимость?</span>
                    Оставьте свои контакты и мы бесплатно Вас проконсультируем<br>
                </h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="form" id="technologies-form">
                    <span class="footer-form-title">Оставьте заявку и получите консультацию</span>
                    <form action="mail.php" method="post" name="form">
                        <input type="hidden" name="utm_content" value="<?=$_GET['utm_content']?>">
                            <input type="hidden" name="utm_medium" value="<?=$_GET['utm_medium']?>">
                            <input type="hidden" name="utm_source" value="<?=$_GET['utm_source']?>">
                            <input type="hidden" name="utm_campaign" value="<?=$_GET['utm_campaign']?>">
                             <input type="hidden" name="utm_term" value="<?=$_GET['utm_term']?>">
                        <input type="text" placeholder="Ваше имя" required=""  name="name" value=""><br>
                        <input type="tel" placeholder="Ваш телефон" required=""  name="phone" value="" id="tel4"><br>
                        <input type="hidden"  required="" name="hidden" value="Письмо отпрвлено с всплывающей формы">
                        <input type="submit" value="ОТПРАВИТЬ" name="submit" class="form-button-style">
                    </form>
                </div>
            </div>
            <div class="col-lg-8">
                <img src="img/arrow%20green.png" alt="" class="arrow-green">
            </div>
        </div>
    </div>
</section>

<!--Экран Современная технология-->
<!-- <section class="technologies">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="technologies-title">
                    СОВРЕМЕННАЯ ТЕХНОЛОГИЯ<br>
                    <span class="technologies-title-bold">ОДНОВРЕМЕННОЙ ПРОДАЖИ<br>
                    И ПОКУПКИ (ОБМЕНА) </span>КВАРТИРЫ
                </h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="form" id="technologies-form">
                    <span class="footer-form-title">Оставьте заявку</span><br>
                    <span class="footer-form-text">и получите уникальный комплекс услуг по одновременной продаже и покупке квартиры:</span>
                    <form action="mail.php" method="post" name="form">
                        <input type="text" placeholder="Ваше имя" required=""  name="name" value=""><br>
                        <input type="tel" placeholder="Ваш телефон" required=""  name="phone" value="" id="tel4"><br>
                        <input type="hidden"  required="" name="hidden" value="Письмо отпрвлено с всплывающей формы">
                        <input type="submit" value="ОТПРАВИТЬ" name="submit" class="form-button-style">
                    </form>
                </div>
            </div>
            <div class="col-lg-8">
                <img src="img/arrow%20green.png" alt="" class="arrow-green">
            </div>
        </div>
    </div>
</section> -->


<!--Экран 7 шагов от заявки до продажи Вашей квартиры-->
<section class="sevensteps" id="sevensteps">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="sevensteps-title">
                    7 шагов от заявки до продажи <br>
                    <span class="sevensteps-title-green">Вашей квартиры</span></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <img src="img/sevensteps-01.png" alt="" class="sevensteps-img">
                <span class="sevensteps-text">Мы перезваниваем Вам и договариваемся о встрече</span>
            </div>
            <div class="col-md-4">
                <img src="img/sevensteps-02.png" alt="" class="sevensteps-img">
                <span class="sevensteps-text">Готовим профессиональную <br>аналитику Вашего объекта</span>
            </div>
            <div class="col-md-4">
                <img src="img/sevensteps-03.png" alt="" class="sevensteps-img">
                <span class="sevensteps-text">Согласовываем стартовую цену <br>и подписываем договор</span>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <img src="img/sevensteps-04.png" alt="" class="sevensteps-img">
                <span class="sevensteps-text">Запускаем рекламную кампанию <br>и фиксируем звонки</span>
            </div>
            <div class="col-md-4">
                <div class="form-mini" id="sevensteps-form-mini">
                    <form action="mail.php" method="post" name="form">
                        <input type="hidden" name="utm_content" value="<?=$_GET['utm_content']?>">
                            <input type="hidden" name="utm_medium" value="<?=$_GET['utm_medium']?>">
                            <input type="hidden" name="utm_source" value="<?=$_GET['utm_source']?>">
                            <input type="hidden" name="utm_campaign" value="<?=$_GET['utm_campaign']?>">
                             <input type="hidden" name="utm_term" value="<?=$_GET['utm_term']?>">
                        <input type="tel" placeholder="Ваш телефон" required=""  name="phone" value="" id="tel5"><br>
                        <input type="hidden"  required="" name="hidden" value="Письмо отпрвлено с всплывающей формы">
                        <input type="submit" value="ОТПРАВИТЬ ЗАЯВКУ" name="submit" class="form-button-style">
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <img src="img/arrow_green_2.png" alt="" class="sevensteps-arrow">
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <img src="img/sevensteps-05.png" alt="" class="sevensteps-img">
                <span class="sevensteps-text">Показываем объект и принимаем встречные заявки по цене</span>
            </div>
            <div class="col-md-4">
                <img src="img/sevensteps-06.png" alt="" class="sevensteps-img">
                <span class="sevensteps-text">Выбираем лучшую цену <br>и условия сделки</span>
            </div>
            <div class="col-md-4">
                <img src="img/sevensteps-07.png" alt="" class="sevensteps-img">
                <span class="sevensteps-text">Выходим на сделку <br>и получаем деньги</span>
            </div>
        </div>
    </div>
</section>













<!---------------------------большие изображения во всплывающем окне---------------------------------->
<div style="display: none;">
    <div class="box-modal" id="modal-img-1">
        <div class="box-modal_close arcticmodal-close"></div>
        <img src="img/certificates-big-01.jpg" alt="" class="certificates-big">
    </div>
</div>
<div style="display: none;">
    <div class="box-modal" id="modal-img-2">
        <div class="box-modal_close arcticmodal-close"></div>
        <img src="img/certificates-big-02.jpg" alt="" class="certificates-big">
    </div>
</div>
<div style="display: none;">
    <div class="box-modal" id="modal-img-3">
        <div class="box-modal_close arcticmodal-close"></div>
        <img src="img/certificates-big-03.jpg" alt="" class="certificates-big">
    </div>
</div>
<!---------------------------большие изображения во всплывающем окне---------------------------------->
<!--Экран Немного о себе -->
<section class="about-me">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="about-me-title">Продажа квартиры с кем?</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3">
			<p> </p>
			<p> </p>
			<p> </p>
			<p class="about-me-text">
                    <b style="font-size: 1.3em;color: #0067a8;font-weight: 700;">Богославский Максим</b><br>Брокер в недвижимости. Партнер Профессионального Сообщества Риелторов г.Киева. Сторонник создания системы MLS (Multiple Listing Service) и лицензирования профессии на законодательном уровне в Украине 
                </p>
            </div>
			<div class="col-lg-6">
                <img class="about-me-img-man" src="img/maxtan111.png">
            </div> 
			<div class="col-lg-3">
			<p> </p>
			<p class="about-me-text">
                    <b style="font-size: 1.3em;color: #0067a8;font-weight: 700;">Богославская Татьяна</b><br>Специалист по продажам жилой недвижимости г.Киева. Член Ассоциации Специалистов по Недвижимости (Риелторов) Украины (АСНУ)
                </p>
            </div>

        </div>






    </div>
</section>
<!--Экран Мы гарантируем Вам -->
<section class="advantages">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="advantages-title">Мы гарантируем  <span class="advantages-green">Вам</span></h2>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <ul class="advantages-ul">
                    <li class="advantages-li">
                        <div class="circle">
                            <img src="img/p1.png" alt="" class="advantages-circle-img-1">
                        </div>
                        <span class="circle-title" style="font-size: 18px;">Профессиональный сервис</span>
                        <span class="circle-text" style="font-size: 15px;">Постоянная степень взаимодействия с Вами в режиме 24/7</span>
                    </li>



                    <li class="advantages-li">
                        <div class="circle">
                            <img src="img/p6.png" alt="" class="advantages-circle-img-3">
                        </div>
                        <span class="circle-title" style="font-size: 18px;">Согласование</span>
                        <span class="circle-text" style="font-size: 15px;">Все наши действия будут согласованы с Вами, и Вы будете в курсе всех событий</span>
                    </li>

                    <li class="advantages-li">
                        <div class="circle">
                            <img src="img/p4.png" alt="" class="advantages-circle-img-4">
                        </div>
                        <span class="circle-title" style="font-size: 18px;">Результат</span>
                        <span class="circle-text" style="font-size: 15px;">Мы гарантированно продадим Вашу недвижимость по самой лучшей цене</span>
                    </li>
	                    <li class="advantages-li">
                        <div class="circle" >
                            <img src="img/p5.png" alt="" class="advantages-circle-img-2">
                        </div>
                        <span class="circle-title" style="font-size: 18px;">Персональный подход</span>
                        <span class="circle-text" style="font-size: 15px;">Выгодный торг в Ваших интересах, Вы всегда будете в плюсе</span>
                    </li>
                </ul>
            </div>
        </div>

        <!--<div class="row">
            <div class="col-lg-12">
                <div class="advantages-bloknot">
                    <img src="img/i_bloknot.png" alt="" class="advantages-bloknot-img">
                </div>
            </div>
        </div>-->
    </div>
</section>
<!--Экран отзывы-->
<section class="sold-apartments" id="reviews">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" style="padding-top: 20px">
                <h2 class="sold-apartments-title">Реальные отзывы клиентов</h2>
            </div>
        </div>
        <img class="loader" src="img/loader.svg" alt="">
        <div class="fb-comments" data-href="http://bogoslavsky.com/" data-width="100%" data-numposts="5"></div>
    </div>
</section>




<!-- Экран карта -->
<section class="map">


</section>


<!-- Экран футер, нижняя часть с контактными данными -->
<footer class="footer" id="kontakt">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <img src="img/logo-feel.jpg" alt="" class="logo-footer">
				            
                <span class="about-me-border-bottom"></span><!-- серая полоса разделяющая блок -->

                <img src="img/logo-footer3.png" alt="" class="logo-footer">
                
            </div>
            <div class="col-lg-3">
                <p class="footer-timetable">
                    <span class="footer-timetable-day">Пн-Пт</span> <span class="footer-timetable-num">9<sup>00</sup>-19<sup>00</sup></span><br>
                    <span class="footer-timetable-day">Сб</span> <span class="footer-timetable-num">10<sup>00</sup>-17<sup>00</sup></span>
                </p>
                <p class="footer-address">
                    <span class="footer-address-city">г. Киев</span><br>
                    <span class="footer-address-street">б-р Дружбы Народов, 24/2 </span><br><p style="font-size: 12px;text-align: center;">(перед приездом, перезвоните)</p> 
                </p>
            </div>
            <div class="col-lg-5">
                <div class="form" id="footer-form">
                    <span class="footer-form-title">Остались вопросы?</span><br>
                    <span class="footer-form-text">Оставьте заявку на обратный звонок и мы ответим на любые Ваши вопросы:</span>
                    <form action="mail.php" method="post" name="form">
                        <input type="hidden" name="utm_content" value="<?=$_GET['utm_content']?>">
                            <input type="hidden" name="utm_medium" value="<?=$_GET['utm_medium']?>">
                            <input type="hidden" name="utm_source" value="<?=$_GET['utm_source']?>">
                            <input type="hidden" name="utm_campaign" value="<?=$_GET['utm_campaign']?>">
                             <input type="hidden" name="utm_term" value="<?=$_GET['utm_term']?>">
                        <input type="text" placeholder="Ваше имя" required=""  name="name" value=""><br>
                        <input type="tel" placeholder="Ваш телефон" required=""  name="phone" value="" id="tel6"><br>
                        <input type="hidden"  required="" name="hidden" value="Письмо отпрвлено с всплывающей формы">
                        <input type="submit" value="ОТПРАВИТЬ" name="submit" class="form-button-style">
                    </form>
                </div>
                <div class="footer-phone">
                    <span class="footer-phone-thin">+38<a href="tel:+380972288620"> <span class="footer-phone-bold" style="color: black;">(097) 228-86-20</span></a></span>
                </div>
                <div class="footer-phone margin-top-0">
                    <span class="footer-phone-thin">+38<a href="tel:+380932400745"> <span class="footer-phone-bold" style="color: black;">(093) 240-07-45</span></a></span>
                </div>
                <div class=''>
                    <div class="row">
                    <div class='btn-wrap blog'><a href='https://bogoslavsky.com/blog' target="_blank" class='btn btn-primary btn-block '>Наш блог</a></div>
                    <div class='btn-wrap telegram'><a href='https://telega.at/dvizh_v_karmane' target="_blank" class='btn btn-primary btn-block '>Наш канал в Telegram</a></div>
                    <div class='btn-wrap telegram-img'><a href="https://telega.at/dvizh_v_karmane"><img src="img/telega.png"></a></div>
                


                </div>
                
            </div>
        </div>

        <div class="row copy-wrap">

            <div class="col-md-12   copyright-margin-top">
			<center><a href="http://bogoslavsky.com/politika.html">Политика конфиденциальности</a> и <a href="http://bogoslavsky.com/soglashenie.html">Пользовательское соглашение</a></center>
                <span class="footer-copyright-2">© 2016 ФЛП Богославский М.Д. ИНН 3353110539, Все права защищены</span>
            </div>
        </div>
    </div>
</footer>

<!-- Настройка слайдера -->
<script>
    /*$(document).ready(function(){
        $('.owl-carousel').owlCarousel({
            loop:true,
            margin:10,
            autoplay:true,
            autoplaySpeed:500,
            navSpeed:1000,
            nav:false,
            responsiveClass:true,
            responsive:{
                0:{
                    items:1,
                    nav:false
                },
                600:{
                    items:1,
                    nav:false
                },
                1000:{
                    items:1,
                    nav:false,
                }
            }
        })
    });*/
</script>
<!-- Настройка слайдера -->
<!-- Таймер -->
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
<!--<script>window.jQuery || document.write('<script src="node_modules/jquery/dist/jquery.min.js"><\/script>')</script>-->
<script src="js/jquery.time-to.js"></script>
<script>
    $('#countdown-3').timeTo({
        timeTo: new Date(new Date('Sun Apr 30 2018 09:00:00 GMT+0300')),
        displayDays: 2,
        theme: "black",
        displayCaptions: true,
        fontSize: 48,
        captionSize: 14
    });
</script>
<!-- Таймер -->
<!-- Менюга -->
<script>
    $(window).scroll(function(){
        if ($(this).scrollTop() > 500) {
            $('.header-menu').addClass('fixed');
        } else {
            $('.header-menu').removeClass('fixed');
        }
    });
</script>
<script type="text/javascript">
    $("a.topLink").click(function() {
        if($(window).width() <= 992){
            $('.header-menu').fadeOut(500);
        }
        
        $("html, body").animate({
            scrollTop: $($(this).attr("href")).offset().top + "px"
        }, {
            duration: 500,
            easing: "swing"
        });
        return false;
    });
    $("#top_scroll, .logo-footer").click(function() {
        
        $("html, body").animate({
            scrollTop: 0 + "px"
        }, {
            duration: 1500,
            easing: "swing"
        });
        return false;
    });



    $('.toggle-mnu').click(function () {
        var _this = $(this);

        if (_this.hasClass('open')) {
            $('.header-menu').slideToggle(500);
            _this.removeClass('open');
        }else{
            $('.header-menu').slideToggle(500);
            _this.addClass('open');
        }

        
    })
</script>
<!-- Менюга -->
<!-- Маска телефона-->
<!--<script type="text/javascript">
    jQuery(function($){
        $("#tel1").mask("+38(999) 999-9999");
    });
    jQuery(function($){
        $("#tel2").mask("+38(999) 999-9999");
    });
    jQuery(function($){
        $("#tel3").mask("+38(999) 999-9999");
    });
    jQuery(function($){
        $("#tel4").mask("+38(999) 999-9999");
    });
    jQuery(function($){
        $("#tel5").mask("+38(999) 999-9999");
    });
    jQuery(function($){
        $("#tel6").mask("+38(999) 999-9999");
    });
</script>-->
<!-- Маска телефона-->
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2078776665735015');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=2078776665735015&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<!--------------------------------------------------
С помощью тега ремаркетинга запрещается собирать информацию, по которой можно идентифицировать личность пользователя. Также запрещается размещать тег на страницах с контентом деликатного характера. Подробнее об этих требованиях и о настройке тега читайте на странице http://google.com/ads/remarketingsetup.
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 800883001;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/800883001/?guid=ON&amp;script=0"/>
</div>
</noscript>

	<script type="text/javascript">


 
$(function() {
 
$(window).scroll(function() {
 
if($(this).scrollTop() != 0) {
 
$('#toTop').fadeIn();
 
} else {
 
$('#toTop').fadeOut();
 
}
 
});
 
$('#toTop').click(function() {
 
$('body,html').animate({scrollTop:0},800);
 
});
 
});
 
</script>

<script>
        (function(w,d,u){
                var s=d.createElement('script');s.async=true;s.src=u+'?'+(Date.now()/60000|0);
                var h=d.getElementsByTagName('script')[0];h.parentNode.insertBefore(s,h);
        })(window,document,'https://cdn.bitrix24.ua/b11803971/crm/site_button/loader_4_uvfb8k.js');
</script>
</body>
</html>